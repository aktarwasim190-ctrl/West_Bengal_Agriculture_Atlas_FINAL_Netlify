# WB AGRI·RS Atlas — West Bengal Agriculture & Remote Sensing

Static Netlify-ready atlas for local raster web tiles for 2015, 2020 and 2025.

## Main files
- `index.html` — atlas landing page
- `map.html` — interactive GIS viewer
- `web_tiles_2015/` — 2015 raster tiles
- `Webtiles_2020/` — 2020 raster tiles
- `web_tiles_2025/` — 2025 raster tiles
- `assets/style.css` — site styles
- `netlify.toml` — static publish configuration

## Viewer features
- West Bengal automatic extent
- 2015 / 2020 / 2025 layer switching
- layer opacity
- OpenStreetMap / Esri Satellite basemap
- coordinate and zoom readout
- swipe comparison mode with draggable divider
- responsive controls for desktop and mobile

## Netlify
Upload the contents of this folder as the deploy directory. Keep the three tile folders and their names unchanged.
